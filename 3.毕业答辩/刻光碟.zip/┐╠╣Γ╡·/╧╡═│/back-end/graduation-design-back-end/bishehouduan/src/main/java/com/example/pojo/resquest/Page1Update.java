package com.example.pojo.resquest;

import lombok.*;

/**
 * @author ljc
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Page1Update {
    private String name;
    private String account;
}
