package com.example.pojo.response;

import lombok.*;

/**
 * @author ljc
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ResponsePate1Update {
    private boolean state=false;
    private String token;
}
