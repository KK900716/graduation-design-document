<template>

</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Click4page"
}
</script>

<style scoped>

</style>