# 不同水体识别系统设计与实现后端

#### 介绍
前端Vue，后端SpringBoot，图像识别YOLOv5，数据库Redis、Mysql
