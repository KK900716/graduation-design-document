package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.multipart.MultipartResolver;

@SpringBootTest
public class TestMultipartResolver {
    @Test
    public void test(){
        System.out.println("abc");
    }
//    @Test
//    public void testMultipartResolver(MultipartResolver multipartResolver){
//    }
}
