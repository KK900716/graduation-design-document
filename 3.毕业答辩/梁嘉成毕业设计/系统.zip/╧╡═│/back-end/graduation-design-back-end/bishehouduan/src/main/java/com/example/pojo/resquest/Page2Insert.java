package com.example.pojo.resquest;

import lombok.*;

/**
 * @author ljc
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Page2Insert {
    private String name;
}
