<template>
  <div class="block">
    <img src="../assets/HomePage/1.png" alt="加载失败">
  </div>
</template>

<script>
export default {
  name: "HomePage"
}
</script>

<style scoped>

</style>